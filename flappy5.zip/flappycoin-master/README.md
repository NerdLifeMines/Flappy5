FlappyCoin  - UPDATE TO 4.0.3.0
================================
Current version: 4.0.3.0

DOMAIN: http://goflap.io

EXPLORER: http://explorer.goflap.io

![FlappyCoin](http://goflap.io/FlappyCoin_files/flapcoin_med.png)

Copyright (c) 2015 Bitcoin Developers

Copyright (c) 2015 FlappyCoin Developers


Specifications:
---------------
Algorithm: Scrypt

Max number of coins 73,000,000,000 FLAP with 1% Stake rewards indefinitely. 

Block Time: 60 Seconds

Difficulty Retarget Time: 1 minutes (with KGW)

Premine: None

Min Stake Age: 3 days

Max Stake Age: 21 days



Rewards:
---------------
Block 1-110,000: 0-1,000,000 Reward

Block 110,001 — 140,000: 0-100,000 Reward

Block 140,001 — 140,500: 0-1,000,000 Reward

Block 140,501 — 200,000: 100,000 Reward

Block 200,001 — 300,000: 50,000 Reward

Block 300,001 — 400,000: 25,000 Reward

Block 400,001 — 500,000: 12,500 Reward

Block 500,001 - 600,000: 6,250 Reward

Block 600,000 - 700,000: 50 + Transaction Fees Reward

Block 700,000+: 10% stake rewards reducing ever 50k blocks by 1% to 1% indefinitely.


Download Links:
----------------

http://goflap.io/

License
-------

Flappycoin is released under the terms of the MIT license. See `COPYING` for more
information or see http://opensource.org/licenses/MIT.
